const drag = document.querySelector('.drag');
const boxes = document.querySelectorAll('.box');

drag.addEventListener('dragstart', dragStart);
drag.addEventListener('dragend', dragEnd);


for (const box of boxes) {
 box.addEventListener('dragover', dragOver);
 box.addEventListener('dragenter', dragEnter);
 box.addEventListener('dragleave', dragLeave);
 box.addEventListener('drop', dragDrop);
}


function dragStart() {
  this.className += ' box';
  setTimeout(() => (this.className = 'invisible'), 0);
}

function dragEnd() {
  this.className = 'drag';
}

function dragOver(e) {
  e.preventDefault();
}

function dragEnter(e) {
  e.preventDefault();
  this.className += ' box';
}

function dragLeave() {
  this.className = 'box';
}

function dragDrop() {
  this.className = 'box';
  this.append(drag);
}
